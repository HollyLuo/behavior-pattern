package citi.holly.my_decision_tree;

import static org.junit.Assert.*;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.junit.Before;
import org.junit.Test;
import weka.core.Instances;
import citi.holly.my_decision_tree.Classifier;

public class ClassifierTest {
	private Classifier classifier;
	
	@Before
	public void setup() throws Exception {
		this.classifier = new Classifier();
		classifier.learn(classifier.loadData("/Users/ling/Documents/Eclipseworkspace/Weka/my-decision-tree/resource/ex3.arff"));	
	}
	
	@Test
	public void visualize() throws Exception {
		((citi.holly.my_decision_tree.Classifier)this.classifier).visualize();
		Thread.currentThread().sleep(300000);
	}

}
