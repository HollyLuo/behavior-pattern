package citi.holly.my_decision_tree;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;

import org.junit.Before;
import org.junit.Test;

public class AttributeSelectTest {
	
	private AttributeSelect select;
	
	@Before
	public void setup() throws Exception {
		File file = new File("/Users/ling/Documents/Eclipseworkspace/Weka/my-decision-tree/resource/ex3.arff");
		this.select = new AttributeSelect(file);
	}
	
	@Test
	public void selectAttribute() throws Exception {
		this.select.selectUsingInfoGainAttributeEval();
		System.out.println("--------------------------------------------");
		this.select.selectUsingGainRatioAttributeEval();

	}
}
